
const loginForm = document.getElementById("loginForm");

if (loginForm) {
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  const errorModal = document.getElementById("errorModal");
  const tryAgainBtn = document.getElementById("tryAgainBtn");

  function showModal() {
    errorModal.style.display = "flex";
  }

  function hideModal() {
    errorModal.style.display = "none";
  }

  loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    if (username === "admin" && password === "password123") {
      window.location.href = "index.html";
    } else {
      showModal();
    }
  });

  if (tryAgainBtn) {
    tryAgainBtn.addEventListener("click", hideModal);
  }
}


const menuToggleBtn = document.getElementById("menuToggle");
const sidebarMenu = document.getElementById("sidebar");      

if (menuToggleBtn && sidebarMenu) {
  function toggleSidebar() {
    
    sidebarMenu.classList.toggle("active");

    
  }

  menuToggleBtn.addEventListener("click", toggleSidebar);
}